/*
*   Roots  -- A collection of static methods for finding the roots of functions.
*
*   Copyright (C) 1999 - 2004 by Joseph A. Huwaldt.
*   All rights reserved.
*   
*   This library is free software; you can redistribute it and/or
*   modify it under the terms of the GNU Lesser General Public
*   License as published by the Free Software Foundation; either
*   version 2 of the License, or (at your option) any later version.
*   
*   This library is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*   Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*   Or visit:  http://www.gnu.org/licenses/lgpl.html
**/
package jahuwaldt.tools.math;


/**
*  A collection of static routines to find the roots
*  of functions or sets of functions.
*
*  <p>  Modified by:  Joseph A. Huwaldt  </p>
*
*  @author   Joseph A. Huwaldt   Date:  October 8, 1997
*  @version  July 13, 2000
**/
public class Roots {

	// Debug flag.
	private static final boolean DEBUG = false;
	
	/**
	*  Machine floating point precision.
	**/
	private static final double	EPS = Double.MIN_VALUE;
	
	/**
	*  Maximum number of allowed iterations.
	**/
	private static final int  MAXIT = 100;

	
	//-----------------------------------------------------------------------------------
	/**
	*  <p>  Find the root of a general 1D function f(x) = 0 known
	*       to lie between x1 and x2.  The root will be refined
	*       until it's accuracy is "tol".  </p>
	*
	*  <p>  Have your Evaluatable1D derivative() function return
	*       Double.NaN (as it does by default) when you want this routine
	*       to use Brent's method.  Newton-Raphson will be used if a
	*       derivative function is provided that returns something other
	*       than Double.NaN.  </p>
	*
	*  @param  eval    An evaluatable 1D function that returns the
	*                  function value at x and optionally returns the
	*                  function derivative value (d(fx)/dx) at x. It is
	*                  guaranteed that "function()" will always be called
	*                  before "derivative()".
	*  @param  x1, x2  The bracket surrounding the root (assumed that
	*                  root lies between x1 and x2).
	*  @param  tol     The root will be refined until it's accuracy is
	*                  better than this.
	*  @return The value of x that solves the equation f(x) = 0.
	*  @exception  RootException  Unable to find a root of the function.
	**/
	public static double findRoot1D( Evaluatable1D eval, double x1,
									double x2, double tol ) throws RootException  {
		double	value = eval.derivative(x1);
		
		if (Double.isNaN(value))
			//	No derivative information available, use Brent's method.
			value = zeroin(eval, x1, x2, tol);
			
		else
			//	Derivative info is available, use Newton-Raphson.
			value = newton(eval, x1, x2, tol);

		return value;
	}


	/**
	*  <p>  Find the root of a function f(x) = 0 known to lie between
	*       x1 and x2.  The root will be refined until it's accuracy
	*       is "tol".  This is the method of choice to find a bracketed
	*       root of a general 1D function when you can not easily compute
	*       the function's derivative.  </p>
	*
	*  <p>  Uses Van Wijngaarden-Dekker-Brent method (Brent's method).
	*       Algorithm:
	*           G.Forsythe, M.Malcolm, C.Moler, Computer methods for mathematical
	*           computations. M., Mir, 1980, p.180 of the Russian edition. </p>
	*
	*  <p>  Ported to Java from Netlib C version by:
	*           Joseph A. Huwaldt, July 10, 2000      </p>
	*
	*  <p>  This function makes use of the bisection procedure combined with
	*       linear or inverse quadric interpolation.
	*       At every step the program operates on three abscissae - a, b, and c.
	*       b - the last and the best approximation to the root,
	*       a - the last but one approximation,
	*       c - the last but one or even earlier approximation than a that
	*           1) |f(b)| <= |f(c)|,
	*           2) f(b) and f(c) have opposite signs, i.e. b and c confine
	*              the root.
	*       At every step zeroin() selects one of the two new approximations, the
	*       former being obtained by the bisection procedure and the latter
	*       resulting in the interpolation (if a,b, and c are all different
	*       the quadric interpolation is utilized, otherwise the linear one).
	*       If the latter (i.e. obtained by the interpolation) point is 
	*       reasonable (i.e. lies within the current interval [b,c] not being
	*       too close to the boundaries) it is accepted. The bisection result
	*       is used otherwise. Therefore, the range of uncertainty is
	*       ensured to be reduced at least by the factor 1.6 on each iteration.
	*  </p>
	*
	*  @param   eval    An evaluatable 1D function that returns the
	*                   function value at x.
	*  @param   x1, x2  The bracket surrounding the root (assumed that
	*                   root lies between x1 and x2).
	*  @param   tol     The root will be refined until it's accuracy is
	*                   better than this.
	*  @return  The value x that solves the equation f(x) = 0.
	*  @exception  RootException  Unable to find a root of the function.
	**/
	private static double zeroin(Evaluatable1D eval, double x1, double x2, double tol)
															throws RootException {
		double a=x1, b=x2, c=x1;		//	Abscissae, descr. see above.
		double fa = eval.function(a);	//	f(a)
		double fb = eval.function(b);	//	f(b)
		double fc = fa;					//	f(c)

		if (DEBUG)
			System.out.println("Using zeroin()...");
			
		// Check for bracketing.
		if ( (fa > 0.0 && fb > 0.0) || (fa < 0.0 & fb < 0.0) )
			throw new RootException("Root must be bracketed.");
		
		//	Main iteration loop
		for(int iter=0; iter < MAXIT; ++iter) {
			if (DEBUG)
				System.out.println("Iteration #" + iter);

			double prev_step = b - a;	//	Distance from the last but one to the last approx.
			double tol_act;				//	Actual tolerance
    		double p;      				//	Interp step is calculated in the form p/q;
    		double q;					//		division is delayed until the last moment.
			double new_step;      		//	Step at this iteration
   
   			if( Math.abs(fc) < Math.abs(fb) ) {
				a = b;					//	Swap data for b to be the best approximation.
				b = c;
				c = a;
				fa=fb;
				fb=fc;
				fc=fa;
			}
			
			// Convergence check.
    		tol_act = 2.*EPS*Math.abs(b) + tol*0.5;
			new_step = 0.5*(c - b);

			if( Math.abs(new_step) <= tol_act || fb == 0.0 )
				return b;				//	An acceptable approximation was found.

			//	Decide if the interpolation can be tried.
			if( Math.abs(prev_step) >= tol_act && Math.abs(fa) > Math.abs(fb) ) {
				// If prev_step was large enough and was in true direction,
				// inverse quadratic interpolation may be tried.
				double s = fb/fa;
				double cb = c - b;
				if( a == c ) {			//	If we have only two distinct points then only
					p = cb*s;			//	linear interpolation can be applied.
					q = 1.0 - s;
				} else {
					//	Quadric inverse interpolation.
					double t = fa/fc;
					double r = fb/fc;
					p = s*( cb*t*(t - r) - (b - a)*(r - 1.0) );
					q = (t - 1.0)*(r - 1.0)*(s - 1.0);
				}
				//  Check wether in bounds
				if( p > 0.0 )			//	p was calculated with the opposite sign;
					q = -q;				//		make p positive and assign possible minus to q.
				else
					p = -p;

				double min1 = (0.75*cb*q - Math.abs(tol_act*q*0.5));
				double min2 = Math.abs(prev_step*q*0.5);
				if (p < min1 && p < min2) {
					/*	If b+p/q falls in [b,c] and isn't too large it is accepted.
						If p/q is too large then use the bisection procedure which
						will reduce the [b,c] range to a greater extent.	*/
					new_step = p/q;
				}
			}

			if( Math.abs(new_step) < tol_act )	//	Adjust the step to be not less than
				if( new_step > 0.0 )			//		tolerance.
					new_step = tol_act;
				else
					new_step = -tol_act;

			a = b;						//	Save the previous approximation.
			fa = fb;
			b += new_step;
			fb = eval.function(b);		//	Do step to a new approxim.
			if( (fb > 0. && fc > 0.) || (fb < 0. && fc < 0.) ) {
				c = a;					//	Adjust c for it to have a sign opp. to that of b.
				fc = fa;
			}
		}
		
		// Max iterations exceeded.
		throw new RootException("Maximun number of iterations exceeded.");
		
	}


	/**
	*  <p>  Find the root of a function f(x) = 0 known to lie between
	*       x1 and x2.  The root will be refined until it's accuracy
	*       is known within "�tol".  This is the method of choice to find a
	*       bracketed root of a general 1D function when you are able to
	*       supply the derivative of the function with x.  </p>
	*
	*  <p>  Uses a combination of Newton-Raphson and bisection. </p>
	*
	*  <p>  Original FORTRAN program, obtained from Netlib, bore this message:
	*       NUMERICAL METHODS: FORTRAN Programs, (c) John H. Mathews 1994.
	*       NUMERICAL METHODS for Mathematics, Science and Engineering, 2nd Ed, 1992,
	*       Prentice Hall, Englewood Cliffs, New Jersey, 07632, U.S.A.
	*       This free software is complements of the author.
	*       Algorithm 2.5 (Newton-Raphson Iteration).
	*       Section 2.4, Newton-Raphson and Secant Methods, Page 84.  </p>
	*
	*  <p>  Ported from FORTRAN to Java by:  Joseph A. Huwaldt, July 11, 2000.
	*       Root bracketing and bisection added to avoid pathologies as suggested by:
	*       Numerical Recipies in C, 2nd Edition, pg. 366.  </p>
	*
	*  @param   eval    An evaluatable 1D function that returns the function
	*                   value at x and optionally returns the function
	*                   derivative value (d(fx)/dx) at x.  It is guaranteed
	*                   that "function()" will always be called before
	*                   "derivative()".
	*  @param   x1, x2  The bracket surrounding the root (assumed that root
	*                   lies between x1 and x2).
	*  @param   tol     The root will be refined until it's accuracy is better
	*                   than this.
	*  @return  The value x that solves the equation f(x) = 0.
	*  @exception  RootException  Unable to find a root of the function.
	**/
	private static double newton(Evaluatable1D eval, double x1,
									double x2, double tol) throws RootException {
		
		if (DEBUG)
			System.out.println("Using newton()...");
			
		// Evaluate the function low and high.
		double fl = eval.function(x1);
		double fh = eval.function(x2);
		
		// Check for bracketing.
		if((fl > 0.0 && fh > 0.0) || (fl < 0.0 && fh < 0.0))
			throw new RootException("Root must be bracketed.");
		
		// If either end of the bracket is the root, we are done.
		if (fl == 0.0) return x1;
		if (fh == 0.0) return x2;
		
		double xh, xl;
		if (fl < 0.0) {
			//  Orient the search so that fn(x1) < 0.
			xl = x1;
			xh = x2;
		} else {
			xh = x1;
			xl = x2;
		}
		
		double p0 = 0.5*(x1 + x2);				//	Initialize the guess for root.
		double y0 = eval.function(p0);			//	Do initial function evaluation.
		
		double dp_old = Math.abs(x2 - x1);		//	Step size before last.
		double dp = dp_old;						//	Last step size.
		
		// Loop over allowed iterations.
		for (int k=0; k < MAXIT; ++k) {
			if (DEBUG)
				System.out.println("Iteration #" + k);
				
			double df = eval.derivative(p0);	// Evaluate the derivative.

			if ( (((p0 - xh)*df - y0)*((p0 - xl)*df - y0) >= 0.0)
						|| (Math.abs(2.0*y0) > Math.abs(dp_old*df)) ) {
				// Use bisection if Newton is out of range or not decreasing fast enough.
				dp_old = dp;
				dp = 0.5*(xh - xl);
				p0 = xl + dp;
				if (xl == p0) return p0;		//	Change in root is negligable.
				
			} else {
				//	Do a regular Newton step.
				dp_old = dp;
				dp = y0/df;
				double p1 = p0;
				p0 = p0 - dp;
				if (p1 == p0)	return p0;		//	Change in root is negligable.
			}
			
			// Do a convergence check.
			if (Math.abs(dp) < tol) return p0;
			
			// Do a function evaluation.
			y0 = eval.function(p0);
			if (y0 < 0.0)						//  Maintain the bracket on the root.
				xl = p0;
			else
				xh = p0;
		}
		
		throw new RootException("Maximun number of iterations exceeded.");
		
	}
	
	
	/**
	*  Used to test out the methods in this class.
	**/
	public static void main(String args[]) {
	
		System.out.println();
		System.out.println("Testing Roots...");
		
		try {
			// Find a root of f(x) = x^3 - 3*x + 2.
			
			// First create an instance of our evaluatable function.
			Evaluatable1D function = new DemoFunction();
			
			// Then call the root finder with brackets on the root and a tolerance.
			// The brackets can be used to isolate which root you want (for instance).
			double root = findRoot1D( function, -10, 0, 0.0001 );
			
			System.out.println("    A root of f(x) = x^3 - 3*x + 2 is " + root);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}


/**
*  <p>  A simple demonstration class that shows how to
*       use the Evaluatable1D class to find the roots
*       of a 1D equation.  Since this class returns
*       a value for derivative(), we are signalling
*       the root finder that we want it to use the
*       Newton-Raphson technique to find the root of the
*       equation.  </p>
*
*  <p>  Modified by:  Joseph A. Huwaldt  </p>
*
*  @author   Joseph A. Huwaldt   Date:  July 13, 2000
*  @version  July 13, 2000
**/
class DemoFunction extends Evaluatable1D {

	/**
	*  User supplied method that calculates the function y = fn(x).
	*  This demonstration returns the value of y = x^3 - 3*x + 2.
	*
	*  @param   x  Independent parameter to the function.
	*  @return  The x^3 - 3*x + 2 evaluated at x.
	**/
	public double function(double x) {
		return (x*x*x - 3.*x + 2.);
	}
	
	/**
	*  Calculates the derivative of the function dy/dx = d fn(x)/dx.
	*  This demonstration returns dy/dx = 3*x^2 - 3.
	*
	*  @param   x  Independent parameter to the function.
	*  @return  The 3*x^2 - 3 evaluated at x.
	**/
	public double derivative(double x) {
		return (3.*x*x - 3.);
	}

}
