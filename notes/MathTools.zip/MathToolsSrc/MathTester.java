import jahuwaldt.tools.math.*;


/**
*  A trivial application that tests out most of the methods
*  in my jahuwaldt.tools.math package.
**/
public class MathTester {

	public static void main(String args[]) {
	
		// Test out the generic MathTools methods.
		MathTools.main(null);
		
		// Test out the Statistics methods.
		Statistics.main(null);
		
		// Test out the Fraction class.
		Fraction.main(null);
		
		// Test out the Roots class.
		Roots.main(null);
		
		// Test out Polynomial class.
		Polynomial.main(null);
		
		//	Test out the Taylor series class.
		TaylorSeries.main(null);
		
		//	Test the linear algebra algorithms.
		LinAlg.main(null);
		
		//	Test the curve-fitting algorithms.
		ModelData.main(null);
		
		//	Test the digital filter algorithms.
		Integrator.main(null);
		FirstOrderLag.main(null);
		Washout.main(null);
		
	}

}
